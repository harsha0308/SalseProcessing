package com.caseStudy.salesProcessingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesProcessingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesProcessingServiceApplication.class, args);
	}

}
